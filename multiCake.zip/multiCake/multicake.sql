-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 28, 2016 at 11:00 AM
-- Server version: 5.6.33-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `multicake`
--

-- --------------------------------------------------------

--
-- Table structure for table `bisounours`
--

CREATE TABLE IF NOT EXISTS `bisounours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `bisounours`
--

INSERT INTO `bisounours` (`id`, `name`, `description`, `image`) VALUES
(11, 'Cheer Bear', 'Cheer practically invented looking on the bright side! She often makes up cheers right on the spot for encouragement or to help solve a problem. Spreading happiness is as evident in her constant smile as they are on her belly badge.', 'toucalin.png'),
(12, 'Tougentille', 'Tougentille a un don pour le partage ! Cette ourse protectrice et généreuse est amie avec tout le monde. Insouciante et affectueuse, elle adore faire des cadeaux… ou des gâteaux ! Elle accorde tellement d’importance au partage que son bidousigne représente deux sucettes en forme de cœurs !', 'tougentille.png'),
(13, 'Toutaquin', 'Pour Toutaquin, s’amuser est une priorité ! Ce qu’il préfère, c’est être avec ses amis ou vivre des aventures, pendant lesquelles il se fait encore plus d’amis ! Intrépide et optimiste, il profite au maximum de ses journées. Son bidousigne, un soleil jaune éclatant et souriant, reflète bien cet état d’esprit !', 'toutaquin.png'),
(14, 'Touronchon', 'Sous ses airs bourrus, Touronchon est un Bisounours au grand cœur  ! Il est doué pour comprendre les enfants et leur rappeler que leurs proches les aiment même quand ils sont grognons. C’est pourquoi son bidousigne représente un nuage et des gouttes de pluie en forme de cœurs.', 'touronchon.png'),
(15, 'Toubisou', 'Toubisou est le plus âgé et le plus sage des Bisounours, et il a toujours de bonnes intentions. Il sait comprendre et conseiller les enfants pour les aider à partager leurs émotions. Son bidousigne, un gros cœur rouge, est parfaitement adapté à sa mission !', 'toubisou.png'),
(16, 'Harmonie', 'Harmonie est une artiste talentueuse, qui réunit tous les Bisounours et les encourage à faire de leur mieux, notamment grâce à la musique. Elle croit que les différences sont essentielles pour créer l’harmonie dans le monde. C’est pourquoi la fleur représentée sur son bidousigne a des pétales de couleurs différentes.', 'harmonie.png'),
(17, 'Toucurieux', 'Rigolote, tendre et joyeuse, Toucurieux est la nièce de Toubisou. Elle veut toujours prendre part aux aventures des « grands », s’intéresse à tout et pose sans arrêt des questions sur tout ! Son bidousigne représente un petit cœur, mais elle est encore trop petite pour savoir quels sont ses pouvoirs.', 'toucurieux.png'),
(18, 'Toubrave le lion', 'Toubrave le lion est le chef des Cousinours. Protecteur et sans peur du danger, il a beaucoup d’humour et un cœur en or, sans parler du plus joli sourire !', 'toubrave.png'),
(19, 'Coeur Brillant', 'Que serait l’équipe des Cousinours sans Coeur Brillant ? Il est celui qui les rassemble ! Il adore les sciences et c’est vraiment son truc. Son intelligence est si grande qu’il n’hésite pas à reformuler les choses afin que tout le monde puisse comprendre.', 'coeur.png'),
(20, 'Lottie Jolie Coeur', 'Lottie Jolie Coeur est certainement, parmi les Cousinours, celle qui montre le plus de compassion et de bienveillance. Gentille et adorable, elle est toujours à l’écoute des problèmes des autres, comme si elle avait le pouvoir de ressentir leurs propres émotions.', 'lottie.png'),
(21, 'Coeur Fondant', 'Vous voulez savoir qui est la plus mignonne, la plus adorable et la plus chou des Cousinours ? C’est Coeur Fondant, bien sûr ! Une évidence pour ceux qui la connaissent déjà. Bien qu’elle soit la plus jeune de l’équipe, elle a la faculté incroyable qu’à ses côtés, les gens se sentent merveilleusement bien !', 'coeurfondant.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
